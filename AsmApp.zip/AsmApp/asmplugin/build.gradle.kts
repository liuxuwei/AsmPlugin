import com.android.build.gradle.internal.scope.publishBuildArtifacts

plugins {
    id("kotlin")
    id("kotlin-kapt")
    id("maven-publish")
    id("groovy")
    id("java-gradle-plugin")
}

gradlePlugin {
    plugins {
        create("asmplugin") {
            group = "com.liu"
            version = "1.0.0"
            id = "com.liu.asmplugin"
            implementationClass = "com.liu.asmplugin.AsmPlugin"
        }
    }
}


publishing {
    //build.gradle 项目可以用
//    publications {
//        create<MavenPublication>("release") {
//            group = "com.liu.asmplugin"
//            groupId = "com.liu"
//            artifactId = "asmplugin"
//            version = "0.0.3"
//            from(components["java"])
//        }
//    }

    repositories {
        maven {
            //推送到本地
            url = uri("../plugin")
        }
    }
}



dependencies {

    implementation(gradleApi())
    implementation(localGroovy())
    implementation ("org.ow2.asm:asm-commons:9.2")
    implementation("com.android.tools.build:gradle:7.2.0")
}
