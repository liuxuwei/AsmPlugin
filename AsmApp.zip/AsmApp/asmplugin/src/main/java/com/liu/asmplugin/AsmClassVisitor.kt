package com.liu.asmplugin

import com.android.build.api.instrumentation.ClassData
import groovyjarjarasm.asm.Opcodes
import org.objectweb.asm.ClassVisitor
import org.objectweb.asm.MethodVisitor

/**
 * @author liuxuwei
 * @date 2024/12/25
 * @description 指定方法插桩
 */
class AsmClassVisitor(classVisitor: ClassVisitor, private val classData: ClassData): ClassVisitor(Opcodes.ASM9, classVisitor) {
    override fun visitMethod(
        access: Int,
        name: String?,
        descriptor: String?,
        signature: String?,
        exceptions: Array<out String>?
    ): MethodVisitor {
        val methodVisitor = super.visitMethod(access, name, descriptor, signature, exceptions)
        return AsmMethodVisitor(api, methodVisitor, access, name?:"", descriptor ?: "", classData.className)
    }


}