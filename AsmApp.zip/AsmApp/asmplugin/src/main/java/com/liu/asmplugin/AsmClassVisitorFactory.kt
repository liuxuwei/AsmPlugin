package com.liu.asmplugin

import com.android.build.api.instrumentation.AsmClassVisitorFactory
import com.android.build.api.instrumentation.ClassContext
import com.android.build.api.instrumentation.ClassData
import org.objectweb.asm.ClassVisitor

/**
 * @author liuxuwei
 * @date 2024/12/25
 * @description ASM 校验哪些类需要插桩
 */
abstract class AsmClassVisitorFactory: AsmClassVisitorFactory<AsmParameters>{
    override fun createClassVisitor(
        classContext: ClassContext,
        nextClassVisitor: ClassVisitor
    ): ClassVisitor {
        return AsmClassVisitor(nextClassVisitor, classContext.currentClassData)
    }

    override fun isInstrumentable(classData: ClassData): Boolean {
        println("isInstrumentable clasData ${classData.className}")
        return !classData.className.contains("Bean") && !classData.className.contains("Binding")
    }

}