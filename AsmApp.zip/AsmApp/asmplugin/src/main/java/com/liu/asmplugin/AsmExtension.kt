package com.liu.asmplugin

/**
 * @author liuxuwei
 * @date 2024/12/25
 * @description
 */
open class AsmExtension {
    open var specificClass: MutableList<String> = mutableListOf()
}