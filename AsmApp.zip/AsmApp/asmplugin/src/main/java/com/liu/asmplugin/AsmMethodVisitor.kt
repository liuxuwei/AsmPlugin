package com.liu.asmplugin

import org.objectweb.asm.MethodVisitor
import org.objectweb.asm.Opcodes
import org.objectweb.asm.Type
import org.objectweb.asm.commons.AdviceAdapter


/**
 * @author liuxuwei
 * @date 2024/12/25
 * @description 执行插桩代码的方法
 */
class AsmMethodVisitor(
    api: Int,
    methodVisitor: MethodVisitor,
    assess: Int,
    name: String,
    descriptor: String,
    private val className: String
) : AdviceAdapter(api, methodVisitor, assess, name, descriptor) {

    private val unHookMethodList = listOf(
        "<init>",
        "<clinit>"
    )


    override fun onMethodEnter() {
        println("onMethodEnter")
        super.onMethodEnter()
        if (unHookMethodList.contains(name)) {
            println("constructor method, ignore")
            return
        }
        val traceName = "${acquireClassName(className)}#$name"
        mv.visitLdcInsn(traceName)
        mv.visitMethodInsn(
            Opcodes.INVOKESTATIC,
            "android/os/Trace",
            "beginSection",
            "(Ljava/lang/String;)V",
            false
        )
    }



    override fun onMethodExit(opcode: Int) {
        mv.visitMethodInsn(
            Opcodes.INVOKESTATIC,
            "android/os/Trace",
            "endSection",
            "()V",
            false
        )
        super.onMethodExit(opcode)
    }


    private fun acquireClassName(className: String): String {
        println("acquireClassName className is : $className")
        val fullClassArray = className.split(".")
        val name = fullClassArray[fullClassArray.size - 1]
        println("class name is : $name")
        return name
    }
}