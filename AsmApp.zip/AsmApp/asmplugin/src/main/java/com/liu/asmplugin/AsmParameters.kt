package com.liu.asmplugin

import com.android.build.api.instrumentation.InstrumentationParameters

/**
 * @author liuxuwei
 * @date 2024/12/25
 * @description
 */
interface AsmParameters: InstrumentationParameters {}